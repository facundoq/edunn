from .model import Model, Phase, ModelWithParameters, ModelWithoutParameters
from .optimizer import Optimizer, BatchedGradientOptimizer, GradientDescent, RMSprop, Adam, MomentumGD, \
    NesterovMomentumGD, SignGD

from .models import *
from . import initializers, plot
from . import metrics, datasets

from edunn.models.fake import FakeModel, FakeError

eps = 1e-12

