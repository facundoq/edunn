import numpy as np
from ..model import ModelWithoutParameters


class Flatten(ModelWithoutParameters):

    def forward(self, x:np.ndarray):
        y = {}
        self.set_cache(x.shape)
        ### COMIENZO DE TU IMPLEMENTACION ###
        pass
        ### FIN DE TU IMPLEMENTACION ###
        return y

    def backward(self, δEδy:np.ndarray):
        δEδx = {}
        original_shape, = self.get_cache()
        ### COMIENZO DE TU IMPLEMENTACION ###
        pass
        ### FIN DE TU IMPLEMENTACION ###
        return δEδx, {}