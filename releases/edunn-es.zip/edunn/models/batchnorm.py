import numpy as np
from ..model import ModelWithParameters
from ..initializers import Initializer,RandomNormal


class BatchNorm(ModelWithParameters):

    def __init__(self, num_features: int, eps: float = 1e-5, #momemtum: float = 0.1, affine: bool = True,
                 gamma_initializer: Initializer = None, beta_initializer: Initializer = None, name=None):
        super().__init__(name=name)
        self.num_features=num_features
        self.eps=eps
        # self.momemtum=momemtum
        # self.affine=affine
        if gamma_initializer is None:
            gamma_initializer = RandomNormal()
        if beta_initializer is None:
            beta_initializer = RandomNormal()
        w = gamma_initializer.create(num_features)
        b = beta_initializer.create(num_features)
        self.register_parameter("w", w)
        self.register_parameter("b", b)
        # self.bias = Bias(num_features, initializer=beta_initializer)

    def forward(self, x:np.ndarray):
        y = {}
        cache = tuple()

        # Retrieve w
        w = self.get_parameters()["w"]
        b = self.get_parameters()["b"]

        ### COMIENZO DE TU IMPLEMENTACION ###
        pass
        ### FIN DE TU IMPLEMENTACION ###

        self.set_cache(cache)
        return y

    def backward(self, δEδy:np.ndarray):
        δEδx, δEδγ, δEδβ = {}, {}, {}
        # Retrieve variables from cache
        (x_norm, std, gamma), = self.get_cache()
        ### COMIENZO DE TU IMPLEMENTACION ###
        pass
        ### FIN DE TU IMPLEMENTACION ###
        δEδbn = {"w":δEδγ, "b":δEδβ}
        return δEδx, δEδbn