import numpy as np

from ..model import ModelWithoutParameters
import edunn as nn

class BinaryCrossEntropy(ModelWithoutParameters):

    '''
    Returns the CrossEntropy between two binary class distributions
    Receives a matrix of probabilities Nx1 for each sample, with the probability
     for class 1, ie if p=0.7, this indicates P(C=1) =0.7 and P(C=0)=0.3
    Receives a a vector of class labels, also one for each sample, with values either 0 or 1.

'''

    def forward(self, y_true:np.ndarray, y:np.ndarray):
        y_true = np.squeeze(y_true)
        assert(len(y_true.shape) == 1)
        assert y.min() >= 0

        n,c=y.shape

        E = np.zeros((n,1))
        ### COMIENZO DE TU IMPLEMENTACION ###
        # print(error)
        pass
        ### FIN DE TU IMPLEMENTACION ###
        assert np.all(np.squeeze(E).shape == y_true.shape)
        self.set_cache(y_true,y)
        return E

    def backward(self, δEδyi):
        y_true,y = self.get_cache()
        δEδy = np.zeros_like(y)
        n,classes = y.shape
        ### COMIENZO DE TU IMPLEMENTACION ###
        pass
        ### FIN DE TU IMPLEMENTACION ###

        return δEδy*δEδyi,{}

