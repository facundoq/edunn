import numpy as np
from ..model import ModelWithoutParameters

def conv2d_forward(x, func, stride = (1,1), pool_size = (1,1)):
    stride_h,stride_w=stride

    bx, cx, hx, wx = x.shape
    ph, pw = pool_size

    hy = int((hx - ph) / stride_h) + 1
    wy = int((wx - pw) / stride_w) + 1
    
    y = np.zeros((bx, cx, hy, wy))

    ### COMIENZO DE TU IMPLEMENTACION ###
    pass
    ### FIN DE TU IMPLEMENTACION ###

    return y

def conv2d_backward_max(dy, x, stride = (1,1), pool_size = (1,1)):
    stride_h,stride_w=stride

    bx, cx, hx, wx = x.shape
    ph, pw = pool_size

    hy = int((hx - ph) / stride_h) + 1
    wy = int((wx - pw) / stride_w) + 1
    
    dx = np.zeros_like(x)

    ### COMIENZO DE TU IMPLEMENTACION ###
                    # get the index in the region i,j where the value is the maximum
                    # only the position of the maximum element in the region i,j gets the incoming gradient, the other gradients are zero
    pass
    ### FIN DE TU IMPLEMENTACION ###

    return dx

def conv2d_backward_avg(dy, x, stride = (1,1), pool_size = (1,1)):
    stride_h,stride_w=stride

    bx, cx, hx, wx = x.shape
    ph, pw = pool_size

    hy = int((hx - ph) / stride_h) + 1
    wy = int((wx - pw) / stride_w) + 1
    
    dx = np.zeros_like(x)

    ### COMIENZO DE TU IMPLEMENTACION ###
    pass
    ### FIN DE TU IMPLEMENTACION ###

    return dx


class MaxPool2d(ModelWithoutParameters):

    def __init__(self, kernel_size: int, stride: int = 1, name=None):
        super().__init__(name=name)
        self.kernel_size=(kernel_size, kernel_size)
        self.stride=(stride,stride)

    def forward(self, x:np.ndarray):
        y = {}
        ### COMIENZO DE TU IMPLEMENTACION ###
        pass
        ### FIN DE TU IMPLEMENTACION ###
        self.set_cache(x)
        return y

    def backward(self, δEδy:np.ndarray):
        δEδx = {}
        x, = self.get_cache()
        ### COMIENZO DE TU IMPLEMENTACION ###
        pass
        ### FIN DE TU IMPLEMENTACION ###
        return δEδx, {}

class AvgPool2d(ModelWithoutParameters):

    def __init__(self, kernel_size: int, stride: int = 1, name=None):
        super().__init__(name=name)
        self.kernel_size=(kernel_size, kernel_size)
        self.stride=(stride,stride)

    def forward(self, x:np.ndarray):
        y = {}
        self.set_cache(x)
        ### COMIENZO DE TU IMPLEMENTACION ###
        pass
        ### FIN DE TU IMPLEMENTACION ###
        return y

    def backward(self, δEδy:np.ndarray):
        δEδx = {}
        x, = self.get_cache()
        ### COMIENZO DE TU IMPLEMENTACION ###
        pass
        ### FIN DE TU IMPLEMENTACION ###
        return δEδx, {}