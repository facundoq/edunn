import numpy as np

from ..model import ModelWithoutParameters

class SquaredError(ModelWithoutParameters):
    def forward(self, y_true:np.ndarray, y:np.ndarray):
        delta = (y - y_true)

        n = y_true.shape[0]
        E = np.zeros((n,1))
        ### YOUR IMPLEMENTATION START  ###
        pass
        ### YOUR IMPLEMENTATION END  ###
        self.set_cache(delta)
        return E

    def backward(self, δEδEi):
        delta, = self.get_cache()
        # Calculate error w.r.t
        # y (the output of the model) and not y_true (which is a fixed value)
        δEδy=np.zeros_like(delta)
        ### YOUR IMPLEMENTATION START  ###
        pass
        ### YOUR IMPLEMENTATION END  ###
        return δEδy,{}
