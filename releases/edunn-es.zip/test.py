import guides.es.edunn as nn

dataset_name = "iris"
x, y, classes = nn.datasets.load_classification(dataset_name)
n, din = x.shape
n_classes = y.max() + 1

# Definición del modelo
layers = [nn.Linear(din, 10),
          nn.Bias(10),
          nn.ReLU(),

          nn.Linear(10, n_classes),
          nn.Bias(n_classes),
          nn.Softmax()
          ]

model = nn.Sequential(layers)
print("Arquitectura de la Red:")
print(model.summary())

error = nn.MeanError(nn.CrossEntropyWithLabels())
# Algoritmo de optimización
optimizer = nn.GradientDescent(lr=0.1, epochs=3000, batch_size=32)

# Algoritmo de optimización
print("Entrenando red con descenso de gradiente:")
history = optimizer.optimize(model, x, y, error, verbose=False)

# Reporte del desempeño
y_pred = model.forward(x)
y_pred_labels = y_pred.argmax(axis=1)
print(f"Accuracy final del modelo en el conjunto de entrenamiento: {nn.metrics.accuracy(y, y_pred_labels) * 100:0.2f}%")

